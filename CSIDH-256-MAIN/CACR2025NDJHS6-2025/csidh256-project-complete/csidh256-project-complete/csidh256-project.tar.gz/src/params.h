#ifndef PARAMS_H
#define PARAMS_H

#include <stdint.h>

// CSIDH-256 参数（比 512 简单很多）
#define LIMBS 4  // 256 / 64 = 4

typedef struct {
    uint64_t limbs[LIMBS];
} bigint256;

// CSIDH-256 素数 p（这是经过精心选择的安全参数）
static const uint64_t CSIDH256_P[4] = {
    0xFFFFFFFFFFFFFFFF,
    0xFFFFFFFFFFFFFFFF,
    0xFFFFFFFFFFFFFFFF,
    0x1FFFFFFFFFFFFFFF  // 注意最高位
};

// 小素数列表（37个，比512的74个少一半）
#define NUM_PRIMES 37
static const int PRIMES[NUM_PRIMES] = {
    3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53,
    59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113,
    127, 131, 137, 139, 149, 151, 157, 163
};

#endif
