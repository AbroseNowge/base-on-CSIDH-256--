#ifndef MONT_FIELD_H
#define MONT_FIELD_H

#include "params.h"
#include <stdbool.h>

// ==================== 基础版本函数声明 ====================

typedef struct {
    bigint256 p;           // 模数
    bigint256 p_inv;       // Montgomery 参数
    bigint256 r_squared;   // R^2 mod p
} mont_field;

// 初始化 Montgomery 域
void mont_field_init(mont_field *mf);

// Montgomery 乘法
void mont_mul(bigint256 *result, const bigint256 *a, const bigint256 *b, const mont_field *mf);

// 转换函数
void to_mont(bigint256 *result, const bigint256 *a, const mont_field *mf);
void from_mont(bigint256 *result, const bigint256 *a, const mont_field *mf);

// 辅助函数
void bigint_add(bigint256 *result, const bigint256 *a, const bigint256 *b);
void bigint_sub(bigint256 *result, const bigint256 *a, const bigint256 *b, const bigint256 *p);
int bigint_compare(const bigint256 *a, const bigint256 *b);

// ==================== 优化版本函数声明 ====================

// 优化版 Montgomery 乘法
void mont_mul_optimized(bigint256 *result, const bigint256 *a, const bigint256 *b, const mont_field *mf);

// 优化版初始化
void mont_field_init_optimized(mont_field *mf);

// 优化版转换函数
void to_mont_optimized(bigint256 *result, const bigint256 *a, const mont_field *mf);
void from_mont_optimized(bigint256 *result, const bigint256 *a, const mont_field *mf);

// ==================== 快速版本函数声明 ====================

// 快速 Montgomery 乘法
void mont_mul_fast(bigint256 *result, const bigint256 *a, const bigint256 *b, const mont_field *mf);

// 快速初始化
void mont_field_init_fast(mont_field *mf);

// 快速转换函数
void to_mont_fast(bigint256 *result, const bigint256 *a, const mont_field *mf);
void from_mont_fast(bigint256 *result, const bigint256 *a, const mont_field *mf);

// ==================== 性能测试辅助函数 ====================

// 获取当前时间（毫秒）
double get_time_ms(void);

// 验证函数
bool verify_montgomery_correctness(void);

#endif // MONT_FIELD_H
